/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.sahil.bouncer;

import java.io.Serializable;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author sahil
 */
@Entity
@XmlRootElement
public class Bouncer implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    final static int GRAVITY_ACCEL = 1;
    final static int DECAY_RATE = 1;
    final static int F_WIDTH = 1000; // Frame width
    final static int F_HEIGHT = 500; // Frame height
    
    @Column
    @NotNull
    @Min(value=0, message = "x must be between 0 to 1000")
    @Max(value=F_WIDTH)
    private Integer x;
    
    @Column
    @NotNull
    @Min(value=0, message = "y must be between 0 to 500")
    @Max(value=F_HEIGHT)
    private Integer y;
    
    @Column
    private Integer yVelocity;

    /**
     * Advances the Bouncer's position and velocity for one frame.
     * Implements bouncing behavior and gravity effect.
     */
    public void advanceOneFrame() {
        // Apply gravity if not on the bottom wall
        if (y < F_HEIGHT) {
            yVelocity += GRAVITY_ACCEL;
        }
        
        // Update position
        y += yVelocity;

        // Check for bounce on top wall
        if (y < 0) {
            y = 0; // Reset position to wall
            yVelocity = -yVelocity - DECAY_RATE; // Reverse and decay velocity
        }

        // Check for bounce on bottom wall
        if (y > F_HEIGHT) {
            y = F_HEIGHT; // Reset position to wall
            yVelocity = -yVelocity - DECAY_RATE; // Reverse and decay velocity
        }
    }
    
    // Standard getters and setters
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public Integer getX() {
        return x;
    }
        
    public void setX(Integer x) {
        this.x = x;
    }

    public Integer getY() {
        return y;
    }

    public void setY(Integer y) {
        this.y = y;
    }

    public Integer getYVelocity() {
        return yVelocity;
    }

    public void setYVelocity(Integer yVelocity) {
        this.yVelocity = yVelocity;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Bouncer)) {
            return false;
        }
        Bouncer other = (Bouncer) object;
        return (this.id != null || other.id == null) && (this.id == null || this.id.equals(other.id));
    }

    @Override
    public String toString() {
        return "cst8218.sahil.bouncer.Bouncer[ id=" + id + " ]";
    }

    public void initDefaults() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void update(Bouncer entity) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
