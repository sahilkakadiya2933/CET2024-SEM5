/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cst8218.sahil.bouncer;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author sahil
 */
@Singleton
public class BouncerGame {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
     final static int CHANGE_RATE = 5; // Defines how many times per second the game state updates.
        
    @EJB
    private BouncerFacade bouncerFacade; // Injection of BouncerFacade instance 
    
    private List<Bouncer> bouncers;
    
    /**
     * Main logic to run the game using an infinite loop.
     */
    @PostConstruct
    public void go() {
        new Thread(() -> {
            // The game runs indefinitely
            while (true) {
                // Update all bouncers and save changes to the database
                bouncers = bouncerFacade.findAll();
                for (Bouncer bouncer : bouncers) {
                    bouncer.advanceOneFrame();
                    bouncerFacade.edit(bouncer);
                }
                // Sleep while waiting to process the next frame of the animation
                try {
                    // Wake up roughly CHANGE_RATE times per second
                    Thread.sleep((long)(1.0 / CHANGE_RATE * 1000));
                } catch (InterruptedException exception) {
                    exception.printStackTrace();
                }
            }
        }).start();
    }
}
