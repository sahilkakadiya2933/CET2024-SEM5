/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import cst8218.sahil.bouncer.Bouncer;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author sahil
 */
@Stateless
@Path("cst8218.sahil.bouncer.bouncer")

public class BouncerFacadeREST extends AbstractFacade<Bouncer> {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    public BouncerFacadeREST() {
        super(Bouncer.class);
    }

    
       @POST
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response createBouncer(Bouncer entity) {
        if (entity.getId() != null) {
            return Response.status(Response.Status.BAD_REQUEST).entity("ID should not be provided for creation.").build();
        }
        entity = initializeDefaults(entity);
        super.create(entity);
        return Response.status(Response.Status.CREATED).entity(entity).build();
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response updateOrReplaceBouncer(@PathParam("id") Long id, Bouncer entity) {
        Bouncer existingBouncer = super.find(id);
        if (existingBouncer == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("Bouncer with ID " + id + " not found.").build();
        }
        
        if (entity.getId() != null && !id.equals(entity.getId())) {
            return Response.status(Response.Status.BAD_REQUEST).entity("ID in the path and entity do not match.").build();
        }
        
        entity.setId(id); // Ensure the entity has the correct ID
        return replaceOrModify(existingBouncer, entity);
    }

    // Utility method to either replace or modify the existing entity based on provided details.
    private Response replaceOrModify(Bouncer existingBouncer, Bouncer newDetails) {
        boolean isFullReplacement = newDetails.getX() != null && newDetails.getY() != null;
        if (isFullReplacement) {
            newDetails = initializeDefaults(newDetails); // For full replacement, ensure defaults are set
            super.edit(newDetails); // Replace the entire entity
            return Response.status(Response.Status.OK).entity(newDetails).build();
        } else {
            // Partial update logic (if only some fields are provided)
            if (newDetails.getX() != null) existingBouncer.setX(newDetails.getX());
            if (newDetails.getY() != null) existingBouncer.setY(newDetails.getY());
            super.edit(existingBouncer);
            return Response.status(Response.Status.OK).entity(existingBouncer).build();
        }
    }

    // Initializes null values to defaults
    private Bouncer initializeDefaults(Bouncer entity) {
        if (entity.getX() == null) entity.setX(0);
        if (entity.getY() == null) entity.setY(0);
        // Add more default initializations here as needed
        return entity;
    }


    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Long id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Bouncer find(@PathParam("id") Long id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Bouncer> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Bouncer> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
